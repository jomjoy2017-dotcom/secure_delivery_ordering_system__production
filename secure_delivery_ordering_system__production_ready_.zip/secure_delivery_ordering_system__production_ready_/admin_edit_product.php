<?php
require 'config.php';
require 'functions.php';
checkAuth(); checkAdmin();

$id = filter_var($_GET['id'] ?? '', FILTER_VALIDATE_INT);
if (!$id) die('Invalid ID');

if (isset($_POST['edit_product'])) {
    verify_csrf_token($_POST['csrf_token'] ?? '');
    $name = trim($_POST['name']);
    $cost = filter_var($_POST['cost_price'], FILTER_VALIDATE_FLOAT);
    $sell = filter_var($_POST['selling_price'], FILTER_VALIDATE_FLOAT);
    
    if (!empty($_FILES['image']['name'])) {
        $image = uploadSecureImage($_FILES['image']);
        if ($image) {
            $old_stmt = $conn->prepare("SELECT image FROM products WHERE id = ?");
            $old_stmt->bind_param("i", $id);
            $old_stmt->execute();
            $old_res = $old_stmt->get_result();
            if ($old_row = $old_res->fetch_assoc()) {
                $oldPath = 'images/' . $old_row['image'];
                if (file_exists($oldPath) && is_file($oldPath)) unlink($oldPath);
            }
            
            $stmt = $conn->prepare("UPDATE products SET name = ?, cost_price = ?, selling_price = ?, image = ? WHERE id = ?");
            $stmt->bind_param("sddsi", $name, $cost, $sell, $image, $id);
            $stmt->execute();
        } else {
            echo "<script>alert('ไฟล์รูปภาพไม่ถูกต้อง');</script>";
        }
    } else {
        $stmt = $conn->prepare("UPDATE products SET name = ?, cost_price = ?, selling_price = ? WHERE id = ?");
        $stmt->bind_param("sddi", $name, $cost, $sell, $id);
        $stmt->execute();
    }
    echo "<script>alert('แก้ไขสำเร็จ');window.location='admin_products.php';</script>";
}

$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$p = $stmt->get_result()->fetch_assoc();
if(!$p) die('Product not found');
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>แก้ไขสินค้า</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="navbar no-print">
    <span>Admin Panel</span>
    <div><a href="admin_index.php">จัดการออเดอร์</a><a href="admin_products.php">กลับ</a></div>
</div>
<div class="container">
    <div class="card">
        <h2>แก้ไขสินค้า: <?= e($p['name']) ?></h2>
        <form method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <div style="margin-bottom:15px;">
                <label>ชื่อสินค้า</label>
                <input type="text" name="name" value="<?= e($p['name']) ?>" required maxlength="50" style="width:100%;">
            </div>
            <div style="margin-bottom:15px;">
                <label>ราคาต้นทุน</label>
                <input type="number" step="0.01" name="cost_price" value="<?= e($p['cost_price']) ?>" required style="width:100%;">
            </div>
            <div style="margin-bottom:15px;">
                <label>ราคาขาย</label>
                <input type="number" step="0.01" name="selling_price" value="<?= e($p['selling_price']) ?>" required style="width:100%;">
            </div>
            <div style="margin-bottom:15px;">
                <label>รูปภาพ (เว้นว่างไว้หากไม่ต้องการเปลี่ยน)</label>
                <input type="file" name="image" accept="image/jpeg, image/png, image/webp, image/gif" style="width:100%;">
            </div>
            <button type="submit" name="edit_product" class="btn">บันทึกการแก้ไข</button>
        </form>
    </div>
</div>
</body>
</html>