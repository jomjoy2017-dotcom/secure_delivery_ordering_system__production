<?php
require 'config.php';
require 'functions.php';
checkAuth(); checkAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    verify_csrf_token($_POST['csrf_token'] ?? '');
    $action = $_POST['action'];
    $cid = filter_var($_POST['order_id'], FILTER_VALIDATE_INT);
    
    if ($cid) {
        if ($action === 'cancel') {
            $stmt = $conn->prepare("UPDATE orders SET status = 'cancelled' WHERE id = ?");
            $stmt->bind_param("i", $cid);
            $stmt->execute();
            echo "<script>alert('ยกเลิกรายการแล้ว');window.location='admin_index.php';</script>";
            exit();
        } elseif ($action === 'confirm') {
            $conn->begin_transaction();
            try {
                $check = $conn->prepare("SELECT user_id, total_price, status FROM orders WHERE id = ? FOR UPDATE");
                $check->bind_param("i", $cid);
                $check->execute();
                $res = $check->get_result();
                if ($row = $res->fetch_assoc()) {
                    if ($row['status'] === 'pending') {
                        $stmt = $conn->prepare("UPDATE orders SET status = 'confirmed' WHERE id = ?");
                        $stmt->bind_param("i", $cid);
                        $stmt->execute();
                        
                        $pointsEarned = floor($row['total_price'] / 100);
                        if ($pointsEarned > 0) {
                            $upd_user = $conn->prepare("UPDATE users SET points = points + ? WHERE id = ?");
                            $upd_user->bind_param("ii", $pointsEarned, $row['user_id']);
                            $upd_user->execute();
                        }
                    }
                }
                $conn->commit();
                echo "<script>alert('ยืนยันรายการและมอบแต้มสะสมเรียบร้อยแล้ว');window.location='admin_index.php';</script>";
                exit();
            } catch(Exception $e) {
                $conn->rollback();
                error_log("Confirm Order Failed: " . $e->getMessage());
                echo "<script>alert('เกิดข้อผิดพลาดในการยืนยันรายการ');</script>";
            }
        }
    }
}

$query = "
    SELECT o.*, u.name, u.phone, u.address, 
           GROUP_CONCAT(CONCAT(p.name, ' (x', oi.quantity, ') - ฿', oi.price) SEPARATOR '||') as item_details
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    JOIN order_items oi ON o.id = oi.order_id
    JOIN products p ON oi.product_id = p.id
    GROUP BY o.id
    ORDER BY o.id DESC
";
$orders = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>จัดการออเดอร์</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="navbar no-print">
    <span>Admin Panel</span>
    <div>
        <a href="admin_index.php">จัดการออเดอร์</a>
        <a href="admin_products.php">จัดการสินค้า</a>
        <a href="admin_reports.php">รายงาน</a>
        <a href="admin_members.php">สมาชิก</a>
        <a href="logout.php">ออกจากระบบ</a>
    </div>
</div>
<div class="container">
    <h2>รายการสั่งซื้อลูกค้า</h2>
    <?php while($o = $orders->fetch_assoc()): ?>
    <div class="card">
        <p><strong>ออเดอร์ #<?= e($o['id']) ?></strong> | <strong>ผู้สั่ง:</strong> <?= e($o['name']) ?> | <strong>เบอร์โทร:</strong> <?= e($o['phone']) ?> | <strong>ที่อยู่:</strong> <?= e($o['address']) ?></p>
        <p><strong>สถานะ:</strong> <?= e($o['status']) ?> | <strong>ยอดรวม:</strong> ฿<?= e($o['total_price']) ?></p>
        <ul>
            <?php
            $items = explode('||', $o['item_details']);
            foreach($items as $item):
                if(trim($item)):
            ?>
            <li><?= e($item) ?></li>
            <?php 
                endif;
            endforeach; 
            ?>
        </ul>
        <div class="no-print" style="margin-top:10px; display:flex; gap:10px;">
            <?php if($o['status'] === 'pending'): ?>
                <form method="post" style="display:inline;">
                    <?= csrf_field() ?>
                    <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                    <button type="submit" name="action" value="confirm" class="btn" style="background:#2ecc71;">ยืนยันการสั่งซื้อ</button>
                    <button type="submit" name="action" value="cancel" class="btn" style="background:#e74c3c;" onclick="return confirm('ต้องการยกเลิกออเดอร์นี้ใช่หรือไม่?');">ยกเลิก</button>
                </form>
            <?php endif; ?>
            <button onclick="window.print()" class="btn" style="background:#3498db;">พิมพ์ใบเสร็จ (PDF)</button>
        </div>
    </div>
    <?php endwhile; ?>
</div>
</body>
</html>