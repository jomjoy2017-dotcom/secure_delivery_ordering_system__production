<?php
require 'config.php';
require 'functions.php';
checkAuth(); checkAdmin();

$stmt = $conn->prepare("SELECT name, phone, address, points FROM users WHERE role = 'customer' ORDER BY id DESC");
$stmt->execute();
$users = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>รายชื่อสมาชิก</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="navbar no-print">
    <span>Admin Panel</span>
    <div>
        <a href="admin_index.php">จัดการออเดอร์</a>
        <a href="admin_products.php">จัดการสินค้า</a>
        <a href="admin_reports.php">รายงาน</a>
        <a href="admin_members.php">สมาชิก</a>
        <a href="logout.php">ออกจากระบบ</a>
    </div>
</div>
<div class="container">
    <div class="card">
        <h2>รายชื่อสมาชิก (ลูกค้า)</h2>
        <div style="overflow-x:auto;">
        <table>
            <tr><th>ชื่อ-นามสกุล</th><th>เบอร์โทร</th><th>ที่อยู่</th><th>แต้มสะสม</th></tr>
            <?php while($u = $users->fetch_assoc()): ?>
            <tr>
                <td><?= e($u['name']) ?></td>
                <td><?= e($u['phone']) ?></td>
                <td><?= e($u['address']) ?></td>
                <td><?= e($u['points']) ?> แต้ม</td>
            </tr>
            <?php endwhile; ?>
        </table>
        </div>
    </div>
</div>
</body>
</html>