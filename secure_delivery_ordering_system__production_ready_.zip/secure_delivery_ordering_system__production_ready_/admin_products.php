<?php
require 'config.php';
require 'functions.php';
checkAuth(); checkAdmin();

if (isset($_POST['add_product'])) {
    verify_csrf_token($_POST['csrf_token'] ?? '');
    $name = trim($_POST['name']);
    $cost = filter_var($_POST['cost_price'], FILTER_VALIDATE_FLOAT);
    $sell = filter_var($_POST['selling_price'], FILTER_VALIDATE_FLOAT);
    
    if (isset($_FILES['image'])) {
        $image = uploadSecureImage($_FILES['image']);
        if ($image) {
            $conn->begin_transaction();
            try {
                $stmt = $conn->prepare("INSERT INTO products (name, cost_price, selling_price, image) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("sdds", $name, $cost, $sell, $image);
                $stmt->execute();
                $newId = $stmt->insert_id;
                
                $code = 'sl' . str_pad($newId, 4, '0', STR_PAD_LEFT);
                $upd = $conn->prepare("UPDATE products SET product_code = ? WHERE id = ?");
                $upd->bind_param("si", $code, $newId);
                $upd->execute();
                
                $conn->commit();
                echo "<script>alert('เพิ่มสินค้าสำเร็จ');window.location='admin_products.php';</script>";
                exit();
            } catch(Exception $e) {
                $conn->rollback();
                unlink('images/' . $image);
                error_log("Product Add Error: " . $e->getMessage());
                echo "<script>alert('เกิดข้อผิดพลาดในการบันทึกข้อมูล');</script>";
            }
        } else {
            echo "<script>alert('ไฟล์รูปภาพไม่ถูกต้อง หรือไม่อนุญาตให้อัปโหลดไฟล์ประเภทนี้');</script>";
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_product'])) {
    verify_csrf_token($_POST['csrf_token'] ?? '');
    $del = filter_var($_POST['delete_id'], FILTER_VALIDATE_INT);
    if ($del) {
        $img_stmt = $conn->prepare("SELECT image FROM products WHERE id = ?");
        $img_stmt->bind_param("i", $del);
        $img_stmt->execute();
        $res = $img_stmt->get_result();
        if ($row = $res->fetch_assoc()) {
            $imgPath = 'images/' . $row['image'];
            if (file_exists($imgPath) && is_file($imgPath)) unlink($imgPath);
            
            $del_stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
            $del_stmt->bind_param("i", $del);
            $del_stmt->execute();
            echo "<script>alert('ลบสินค้าสำเร็จ');window.location='admin_products.php';</script>";
            exit();
        }
    }
}

$limit = 20;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $limit;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$searchTerm = "%{$search}%";

$count_stmt = $conn->prepare("SELECT COUNT(*) as total FROM products WHERE product_code LIKE ? OR name LIKE ?");
$count_stmt->bind_param("ss", $searchTerm, $searchTerm);
$count_stmt->execute();
$total_rows = $count_stmt->get_result()->fetch_assoc()['total'];
$total_pages = max(1, ceil($total_rows / $limit));
$page = min($page, $total_pages);
$offset = ($page - 1) * $limit;

$stmt = $conn->prepare("SELECT * FROM products WHERE product_code LIKE ? OR name LIKE ? ORDER BY id DESC LIMIT ? OFFSET ?");
$stmt->bind_param("ssii", $searchTerm, $searchTerm, $limit, $offset);
$stmt->execute();
$products = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>จัดการสินค้า</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="navbar">
    <span>Admin Panel</span>
    <div>
        <a href="admin_index.php">จัดการออเดอร์</a>
        <a href="admin_products.php">จัดการสินค้า</a>
        <a href="admin_reports.php">รายงาน</a>
        <a href="admin_members.php">สมาชิก</a>
        <a href="logout.php">ออกจากระบบ</a>
    </div>
</div>
<div class="container">
    <div class="card">
        <h2>เพิ่มสินค้าใหม่</h2>
        <form method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <input type="text" name="name" placeholder="ชื่อสินค้า (ไม่เกิน 50 ตัวอักษร)" maxlength="50" required style="margin-right:10px;margin-bottom:10px;">
            <input type="number" step="0.01" name="cost_price" placeholder="ราคาต้นทุน" required style="margin-right:10px;margin-bottom:10px;">
            <input type="number" step="0.01" name="selling_price" placeholder="ราคาขาย" required style="margin-right:10px;margin-bottom:10px;">
            <input type="file" name="image" accept="image/jpeg, image/png, image/webp, image/gif" required style="margin-right:10px;margin-bottom:10px;">
            <button type="submit" name="add_product" class="btn">บันทึก</button>
        </form>
    </div>
    <div class="card">
        <h2>รายการสินค้า</h2>
        <form method="get" style="margin-bottom:15px;">
            <input type="text" name="search" placeholder="ค้นหารหัส หรือชื่อสินค้า" value="<?= e($search) ?>">
            <button type="submit" class="btn">ค้นหา</button>
        </form>
        <div style="overflow-x:auto;">
        <table>
            <tr><th>รูปภาพ</th><th>รหัสสินค้า</th><th>ชื่อสินค้า</th><th>ต้นทุน</th><th>ราคาขาย</th><th>จัดการ</th></tr>
            <?php while($p = $products->fetch_assoc()): ?>
            <tr>
                <td><img src="images/<?= e($p['image']) ?>" style="width:60px;height:60px;object-fit:cover;border-radius:5px;"></td>
                <td style="font-family:'Courier New',Courier,monospace;text-align:center;"><?= e($p['product_code']) ?></td>
                <td><?= e($p['name']) ?></td>
                <td>฿<?= e($p['cost_price']) ?></td>
                <td>฿<?= e($p['selling_price']) ?></td>
                <td>
                    <a href="admin_edit_product.php?id=<?= $p['id'] ?>" class="btn" style="background:#f39c12;padding:5px 10px;margin-bottom:5px;">แก้ไข</a>
                    <form method="post" style="display:inline;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="delete_id" value="<?= $p['id'] ?>">
                        <button type="submit" name="delete_product" class="btn" style="background:#e74c3c;padding:5px 10px;" onclick="return confirm('ยืนยันการลบสินค้าหรือไม่? รูปภาพจะถูกลบออกจากระบบด้วย');">ลบ</button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
        </div>
        <div style="margin-top:20px;text-align:center;">
            <?php if($page > 1): ?>
                <a href="?page=<?= $page - 1 ?>&search=<?= urlencode($search) ?>" class="btn btn-secondary">ก่อนหน้า</a>
            <?php else: ?>
                <span class="btn btn-secondary" style="opacity:0.5;cursor:not-allowed;">ก่อนหน้า</span>
            <?php endif; ?>
            
            <span style="margin:0 15px;">หน้า <?= e($page) ?> จาก <?= e($total_pages) ?></span>
            
            <?php if($page < $total_pages): ?>
                <a href="?page=<?= $page + 1 ?>&search=<?= urlencode($search) ?>" class="btn btn-secondary">ถัดไป</a>
            <?php else: ?>
                <span class="btn btn-secondary" style="opacity:0.5;cursor:not-allowed;">ถัดไป</span>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>