<?php
require 'config.php';
require 'functions.php';
checkAuth(); checkAdmin();

$allowed_filters = ['daily', 'monthly', 'yearly'];
$filter = isset($_GET['filter']) && in_array($_GET['filter'], $allowed_filters) ? $_GET['filter'] : 'daily';

$whereClause = "DATE(o.created_at) = CURDATE()";
if ($filter === 'monthly') {
    $whereClause = "MONTH(o.created_at) = MONTH(CURDATE()) AND YEAR(o.created_at) = YEAR(CURDATE())";
} elseif ($filter === 'yearly') {
    $whereClause = "YEAR(o.created_at) = YEAR(CURDATE())";
}

$q = "SELECT o.id as order_id, o.total_price, o.created_at, SUM(oi.quantity * p.cost_price) as total_cost 
      FROM orders o 
      JOIN order_items oi ON o.id = oi.order_id 
      JOIN products p ON oi.product_id = p.id 
      WHERE $whereClause AND o.status = 'confirmed' 
      GROUP BY o.id";
$report = $conn->query($q);

$total_sales = 0;
$total_profit = 0;
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>รายงานการขาย</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="navbar no-print">
    <span>Admin Panel</span>
    <div>
        <a href="admin_index.php">จัดการออเดอร์</a>
        <a href="admin_products.php">จัดการสินค้า</a>
        <a href="admin_reports.php">รายงาน</a>
        <a href="admin_members.php">สมาชิก</a>
        <a href="logout.php">ออกจากระบบ</a>
    </div>
</div>
<div class="container">
    <div class="card no-print">
        <h2>เลือกรายงาน</h2>
        <form method="get">
            <select name="filter" style="padding:10px;margin-right:10px;">
                <option value="daily" <?= $filter == 'daily' ? 'selected' : '' ?>>ประจำวัน</option>
                <option value="monthly" <?= $filter == 'monthly' ? 'selected' : '' ?>>ประจำเดือน</option>
                <option value="yearly" <?= $filter == 'yearly' ? 'selected' : '' ?>>ประจำปี</option>
            </select>
            <button type="submit" class="btn">ดูรายงาน</button>
            <button type="button" onclick="window.print()" class="btn" style="background:#3498db;">พิมพ์ PDF</button>
        </form>
    </div>
    <div class="card">
        <h2>รายงานการขาย (<?= ucfirst($filter) ?>)</h2>
        <div style="overflow-x:auto;">
        <table>
            <tr><th>รหัสการสั่งซื้อ</th><th>วันที่และเวลา</th><th>ยอดขาย (บาท)</th><th>ต้นทุน (บาท)</th><th>กำไร/ขาดทุน (บาท)</th></tr>
            <?php while($r = $report->fetch_assoc()): 
                $profit = $r['total_price'] - $r['total_cost'];
                $total_sales += $r['total_price'];
                $total_profit += $profit;
            ?>
            <tr>
                <td>#<?= e($r['order_id']) ?></td>
                <td><?= e($r['created_at']) ?></td>
                <td><?= number_format($r['total_price'], 2) ?></td>
                <td><?= number_format($r['total_cost'], 2) ?></td>
                <td style="color:<?= $profit >= 0 ? 'green' : 'red' ?>;font-weight:bold;"><?= number_format($profit, 2) ?></td>
            </tr>
            <?php endwhile; ?>
            <tr>
                <td colspan="2" style="text-align:right;"><strong>รวมทั้งหมด</strong></td>
                <td><strong><?= number_format($total_sales, 2) ?></strong></td>
                <td></td>
                <td><strong><?= number_format($total_profit, 2) ?> บาท</strong></td>
            </tr>
        </table>
        </div>
    </div>
</div>
</body>
</html>