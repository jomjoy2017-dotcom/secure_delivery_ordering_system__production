<?php
require 'config.php';
require 'functions.php';
checkAuth();

$uid = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $uid);
$stmt->execute();
$u = $stmt->get_result()->fetch_assoc();

if (isset($_POST['confirm_order'])) {
    verify_csrf_token($_POST['csrf_token'] ?? '');
    if (!empty($_SESSION['cart'])) {
        $conn->begin_transaction();
        try {
            $total = 0;
            $order_stmt = $conn->prepare("INSERT INTO orders (user_id, total_price, status) VALUES (?, 0, 'pending')");
            $order_stmt->bind_param("i", $uid);
            $order_stmt->execute();
            $order_id = $order_stmt->insert_id;
            
            $item_stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
            
            $cart_ids = array_map('intval', array_keys($_SESSION['cart']));
            $ids_str = implode(',', $cart_ids);
            if(empty($ids_str)) throw new Exception("Cart is empty");
            
            $products_res = $conn->query("SELECT id, name, selling_price FROM products WHERE id IN ($ids_str)");
            $valid_products = [];
            while($p = $products_res->fetch_assoc()) {
                $valid_products[$p['id']] = $p;
            }
            
            foreach ($_SESSION['cart'] as $pid => $qty) {
                $pid = (int)$pid; $qty = (int)$qty;
                if(!isset($valid_products[$pid])) {
                    throw new Exception("สินค้าบางรายการไม่มีในระบบแล้ว กรุณาตรวจสอบตะกร้าใหม่");
                }
                $price = $valid_products[$pid]['selling_price'];
                $subtotal = $price * $qty;
                $total += $subtotal;
                $item_stmt->bind_param("iiid", $order_id, $pid, $qty, $price);
                $item_stmt->execute();
            }
            
            $upd_order = $conn->prepare("UPDATE orders SET total_price = ? WHERE id = ?");
            $upd_order->bind_param("di", $total, $order_id);
            $upd_order->execute();
            
            $conn->commit();
            unset($_SESSION['cart']);
            echo "<script>alert('ยืนยันการสั่งซื้อ ยอดรวม ".e($total)." บาท รอเจ้าหน้าที่มายืนยันและจัดส่ง');window.location='index.php';</script>";
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            error_log("Order Failed: " . $e->getMessage());
            $errorMsg = e($e->getMessage());
            echo "<script>alert('เกิดข้อผิดพลาดในการสั่งซื้อ: {$errorMsg}');</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>ตะกร้าสินค้า</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="navbar"><a href="index.php">กลับหน้าหลัก</a></div>
<div class="container">
    <h2>รายการสั่งซื้อของคุณ</h2>
    <div class="card">
        <p><strong>ชื่อ-นามสกุล:</strong> <?= e($u['name']) ?> | <strong>เบอร์โทร:</strong> <?= e($u['phone']) ?> | <strong>ที่อยู่:</strong> <?= e($u['address']) ?></p>
        <?php if(!empty($_SESSION['cart'])): ?>
        <table>
            <tr><th>สินค้า</th><th>จำนวน</th><th>ราคา/หน่วย</th><th>รวม</th></tr>
            <?php 
            $sum = 0;
            $cart_ids = array_map('intval', array_keys($_SESSION['cart']));
            if(!empty($cart_ids)) {
                $ids_str = implode(',', $cart_ids);
                $fetch_p = $conn->query("SELECT id, name, selling_price FROM products WHERE id IN ($ids_str)");
                $products_data = [];
                while($row = $fetch_p->fetch_assoc()) {
                    $products_data[$row['id']] = $row;
                }
                foreach($_SESSION['cart'] as $pid => $qty): 
                    if(!isset($products_data[$pid])) continue;
                    $p = $products_data[$pid];
                    $sub = $p['selling_price'] * $qty;
                    $sum += $sub;
            ?>
            <tr>
                <td><?= e($p['name']) ?></td>
                <td><?= e($qty) ?></td>
                <td>฿<?= e($p['selling_price']) ?></td>
                <td>฿<?= e($sub) ?></td>
            </tr>
            <?php 
                endforeach; 
            }
            ?>
            <tr><td colspan="3" style="text-align:right;"><strong>ยอดรวมทั้งหมด</strong></td><td><strong>฿<?= e($sum) ?></strong></td></tr>
        </table>
        <form method="post" style="margin-top:20px;text-align:right;">
            <?= csrf_field() ?>
            <button type="submit" name="confirm_order" class="btn" style="font-size:1.1em;">ยืนยันการสั่งซื้อ</button>
        </form>
        <?php else: ?>
        <p style="text-align:center;color:#888;">ไม่มีสินค้าในตะกร้า</p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>