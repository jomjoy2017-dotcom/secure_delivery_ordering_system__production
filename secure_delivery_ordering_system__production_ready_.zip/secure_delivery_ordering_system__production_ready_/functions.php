<?php
function checkAuth() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit();
    }
}

function checkAdmin() {
    if ($_SESSION['role'] !== 'admin') {
        header('Location: index.php');
        exit();
    }
}

function e($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf_token($token) {
    if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        die('CSRF Token Validation Failed.');
    }
}

function csrf_field() {
    return '<input type="hidden" name="csrf_token" value="' . generate_csrf_token() . '">';
}

function uploadSecureImage($file) {
    if ($file['error'] !== UPLOAD_ERR_OK) return false;
    
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    $allowed_mimes = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/gif'  => 'gif',
        'image/webp' => 'webp'
    ];
    if (!array_key_exists($mime, $allowed_mimes)) return false;
    
    $ext = $allowed_mimes[$mime];
    $new_name = bin2hex(random_bytes(16)) . '.' . $ext;
    $upload_dir = 'images/';
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
    
    if (move_uploaded_file($file['tmp_name'], $upload_dir . $new_name)) {
        return $new_name;
    }
    return false;
}
?>