<?php
require 'config.php';
require 'functions.php';
checkAuth();

if (isset($_POST['add_to_cart'])) {
    verify_csrf_token($_POST['csrf_token'] ?? '');
    $pid = filter_var($_POST['product_id'], FILTER_VALIDATE_INT);
    $qty = filter_var($_POST['qty'], FILTER_VALIDATE_INT);
    
    if ($pid && $qty && $qty > 0) {
        if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
        $_SESSION['cart'][$pid] = ($_SESSION['cart'][$pid] ?? 0) + $qty;
        echo "<script>alert('เพิ่มลงตะกร้าแล้ว');</script>";
    }
}

$products = $conn->query("SELECT * FROM products ORDER BY id DESC");

$uid = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT points FROM users WHERE id = ?");
$stmt->bind_param("i", $uid);
$stmt->execute();
$u = $stmt->get_result()->fetch_assoc();
$pts = $u['points'] ?? 0;
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>สั่งซื้อสินค้า</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="navbar">
    <span>ยินดีต้อนรับคุณ <?= e($_SESSION['name']) ?> | แต้มสะสม: <?= e($pts) ?> แต้ม</span>
    <div>
        <a href="cart.php">ตะกร้าสินค้า (<?= isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0 ?>)</a>
        <a href="logout.php">ออกจากระบบ</a>
    </div>
</div>
<div class="container">
    <h2>เมนูสินค้าเดลิเวอร์รี่</h2>
    <div style="display:flex;flex-wrap:wrap;gap:20px;">
        <?php while($p = $products->fetch_assoc()): ?>
        <div class="card" style="width:220px;text-align:center;">
            <img src="images/<?= e($p['image']) ?>" alt="img" style="width:100%;height:180px;object-fit:cover;border-radius:10px;">
            <h3><?= e($p['name']) ?></h3>
            <p style="color:#ff4757;font-size:1.2em;font-weight:bold;">฿<?= e($p['selling_price']) ?></p>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                <input type="number" name="qty" value="1" min="1" style="width:60px;margin-bottom:15px;"><br>
                <button type="submit" name="add_to_cart" class="btn">เพิ่มลงตะกร้า</button>
            </form>
        </div>
        <?php endwhile; ?>
    </div>
</div>
</body>
</html>