<?php
require 'config.php';
require 'functions.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_token($_POST['csrf_token'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    $stmt = $conn->prepare("SELECT id, username, password, role, name FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $res = $stmt->get_result();
    
    if ($row = $res->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['role'] = $row['role'];
            $_SESSION['name'] = $row['name'];
            
            if ($row['role'] === 'admin') {
                header("Location: admin_index.php");
            } else {
                header("Location: index.php");
            }
            exit();
        }
    }
    $error = 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง';
}
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>เข้าสู่ระบบ</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container" style="max-width:400px;margin-top:50px;">
    <div class="card">
        <h2 style="text-align:center;">เข้าสู่ระบบ</h2>
        <?php if($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
        <form method="post">
            <?= csrf_field() ?>
            <input type="text" name="username" placeholder="ชื่อผู้ใช้" required style="display:block;width:100%;margin-bottom:15px;">
            <input type="password" name="password" placeholder="รหัสผ่าน" required style="display:block;width:100%;margin-bottom:15px;">
            <button type="submit" class="btn" style="width:100%;margin-bottom:10px;">เข้าสู่ระบบ</button>
            <a href="register.php" class="btn btn-secondary" style="display:block;text-align:center;">สมัครสมาชิก</a>
        </form>
    </div>
</div>
</body>
</html>