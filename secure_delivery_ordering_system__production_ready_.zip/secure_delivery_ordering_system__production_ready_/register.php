<?php
require 'config.php';
require 'functions.php';
$message = ''; $msgType = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_token($_POST['csrf_token'] ?? '');
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    
    if (strlen($username) < 4 || strlen($username) > 50) {
        $message = 'ชื่อผู้ใช้ต้องมีความยาว 4-50 ตัวอักษร'; $msgType = 'danger';
    } elseif (strlen($password) < 6) {
        $message = 'รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร'; $msgType = 'danger';
    } elseif (!preg_match('/^[0-9]{10}$/', $phone)) {
        $message = 'เบอร์โทรศัพท์ต้องเป็นตัวเลข 10 หลักเท่านั้น'; $msgType = 'danger';
    } else {
        $check = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $check->bind_param("s", $username);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            $message = 'ชื่อผู้ใช้นี้มีในระบบแล้ว'; $msgType = 'danger';
        } else {
            $hash_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (username, password, role, name, phone, address, points) VALUES (?, ?, 'customer', ?, ?, ?, 0)");
            $stmt->bind_param("sssss", $username, $hash_password, $name, $phone, $address);
            if ($stmt->execute()) {
                echo "<script>alert('สมัครสมาชิกสำเร็จ');window.location='login.php';</script>";
                exit();
            } else {
                error_log("Registration Error: " . $stmt->error);
                $message = 'เกิดข้อผิดพลาดในการลงทะเบียน'; $msgType = 'danger';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>สมัครสมาชิก</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container" style="max-width:500px;margin-top:50px;">
    <div class="card">
        <h2 style="text-align:center;">สมัครสมาชิก</h2>
        <?php if($message): ?><div class="alert alert-<?= $msgType ?>"><?= e($message) ?></div><?php endif; ?>
        <form method="post">
            <?= csrf_field() ?>
            <input type="text" name="username" placeholder="ชื่อผู้ใช้ (4-50 ตัวอักษร)" required minlength="4" maxlength="50" style="display:block;width:100%;margin-bottom:10px;">
            <input type="password" name="password" placeholder="รหัสผ่าน (อย่างน้อย 6 ตัวอักษร)" required minlength="6" style="display:block;width:100%;margin-bottom:10px;">
            <input type="text" name="name" placeholder="ชื่อ-นามสกุล" required maxlength="100" style="display:block;width:100%;margin-bottom:10px;">
            <input type="text" name="phone" placeholder="เบอร์โทร (ตัวเลข 10 หลัก)" required pattern="[0-9]{10}" style="display:block;width:100%;margin-bottom:10px;">
            <textarea name="address" placeholder="ที่อยู่" required style="display:block;width:100%;margin-bottom:15px;height:80px;"></textarea>
            <button type="submit" class="btn" style="width:100%;margin-bottom:10px;">ยืนยันสมัครสมาชิก</button>
            <a href="login.php" class="btn btn-secondary" style="display:block;text-align:center;">กลับไปหน้าเข้าสู่ระบบ</a>
        </form>
    </div>
</div>
</body>
</html>